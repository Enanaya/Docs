function validate() {
    //if any question is not finished,make this false
    var checkflag = true;
    //store the error info and print it by alert
    var str = "";

     // Name check
    var names = document.getElementsByName("UserInfo");
    var name = names[0].value;
    //if not complete,change the color of this element
    var nameP=document.getElementById("UserInfo");
    var nameCheck=true;
    if (name.length ===0||name.match(/^[ ]+$/)) {
        checkflag = false;
        nameCheck=false;
        str += "Name ";
    }
    // nameP.style.backgroundColor='Yellow';
    nameCheck===false?nameP.style.backgroundColor='Yellow':nameP.style.backgroundColor='White';

    //Q1 check
    var selections = document.getElementsByName("Q1");
    var selection1 = selections[0];
    var Q1Check=true;
    var Q1P=document.getElementById("Q1");
        if (selection1.options[0].selected) {
            checkflag=false;
            Q1Check=false;
            str+="Q1 ";
        }
    Q1Check===false?Q1P.style.backgroundColor='Yellow':Q1P.style.backgroundColor='White';

    // Q2 check
    var  Q2Count=0;
    var q2a = document.getElementById("Q2a");
    var q2b = document.getElementById("Q2b");
    var q2c = document.getElementById("Q2c");
    var q2d = document.getElementById("Q2d");
    var Q2P=document.getElementById("Q2");
    var Q2Check=true;
    var  arrQ2=[q2a,q2b,q2c,q2d];

    arrQ2.forEach(function (item) { if (item.checked) Q2Count++;});
    if (Q2Count>2||Q2Count===1){
        str="Q2: please select two !   "+str;
        checkflag=false;
        Q2Check=false;
    }else if (Q2Count===0){
        str+="Q2 ";
        checkflag=false;
        Q2Check=false;
    }
    Q2Check===false?Q2P.style.backgroundColor='Yellow':Q2P.style.backgroundColor='White';


    // Q3 check
    var Q3check=false;
    var Q3arr = document.getElementsByName("Q3");
    var Q3P=document.getElementById("Q3");
    Q3arr.forEach(function (item) {
        if (item.checked)
            Q3check=true;
    });
    if (!Q3check){
        str+="Q3 ";
    }
    Q3check===false?Q3P.style.backgroundColor='Yellow':Q3P.style.backgroundColor='White';

    // Q4 check
    var Q4arr = document.getElementsByName("Q4");
    var Q4 = Q4arr[0].value;
    var Q4P=document.getElementById("Q4");
    var Q4Check=true;
    // console.dir(Q4.value);
    if (Q4.length===0||Q4.match(/^[ ]+$/)){
        checkflag=false;
        Q4Check=false;
        str+="Q4 ";
    }
    Q4Check===false?Q4P.style.backgroundColor='Yellow':Q4P.style.backgroundColor='White';

    //check and submit
    if (!checkflag) {
        alert(str + "not complete!");
    }

    if (checkflag) {

        var scores = document.getElementsByName("thisScore");
        var score = scores[0].value;
        score = 0;
        //answer: 1.Hello 2. a c 3.b 4.British Sign Language, Australian and New Zealand Sign Language
        if (name.length !== 0 || !name.match(/^[ ]+$/))
            score += 1;
        if (selection1.options[3].selected)
            score += 1;
        if (q2a.checked && q2c.checked)
            score += 1;
        if (Q3arr[1].checked)
            score += 1;
        if (Q4.toUpperCase()===("British Sign Language, Australian and New Zealand Sign Language".toUpperCase()))
            score += 1;
        scores[0].value = score.toString();
        // return false;
        return confirm("your score:  " + score +"  ; are you sure? answers and score will be sent to the server and see result page ?");
    }
    return checkflag;
}
